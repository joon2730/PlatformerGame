package main;

import java.io.FileNotFoundException;

import game.*;

//import java.util.Random;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
    	World world = new World(25, 720, 480);
	}

}
